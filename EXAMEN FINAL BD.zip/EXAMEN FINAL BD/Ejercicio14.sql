-- Habilitar opciones avanzadas
EXEC sp_configure 'show advanced options', 1;
RECONFIGURE;
GO

EXEC sp_configure 'max server memory (MB)', 8192; 
RECONFIGURE;
GO

EXEC sp_configure 'min server memory (MB)', 2048;  
RECONFIGURE;
GO

EXEC sp_configure 'max server memory (MB)';
EXEC sp_configure 'min server memory (MB)';
GO
