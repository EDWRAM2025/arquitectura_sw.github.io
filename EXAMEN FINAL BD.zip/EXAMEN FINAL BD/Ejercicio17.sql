-- Paso 1: Crear los Endpoints de Comunicaci�n (en ambos servidores)

-- En el servidor principal
USE master;
GO
CREATE ENDPOINT MirroringEndpoint
    STATE = STARTED
    AS TCP (LISTENER_PORT = 5022, LISTENER_IP = ALL)
    FOR DATABASE_MIRRORING (ROLE = ALL);
GO

-- En el servidor espejo
USE master;
GO
CREATE ENDPOINT MirroringEndpoint
    STATE = STARTED
    AS TCP (LISTENER_PORT = 5022, LISTENER_IP = ALL)
    FOR DATABASE_MIRRORING (ROLE = ALL);
GO

-- Paso 2: Configuraci�n de la Base de Datos en el Servidor Principal

-- Cambiar el modelo de recuperaci�n a FULL si a�n no est� configurado
USE master;
GO
ALTER DATABASE DBVENTASDEMO SET RECOVERY FULL;
GO

-- Realizar una copia de seguridad completa de la base de datos
BACKUP DATABASE DBVENTASDEMO TO DISK = 'C:\Backups\DBVENTASDEMO.bak';
GO

-- Configurar la base de datos en el servidor principal para el espejo
ALTER DATABASE DBVENTASDEMO SET PARTNER = 'TCP://<IP_SERVIDOR_ESPEJO>:5022';
GO

-- Paso 3: Restaurar la Base de Datos en el Servidor Espejo

-- Restaurar la copia de seguridad en el servidor espejo en modo NORECOVERY
USE master;
GO
RESTORE DATABASE DBVENTASDEMO FROM DISK = 'C:\Backups\DBVENTASDEMO.bak' WITH NORECOVERY;
GO

-- Configurar la base de datos en el servidor espejo para que sea el espejo
ALTER DATABASE DBVENTASDEMO SET PARTNER = 'TCP://<IP_SERVIDOR_PRINCIPAL>:5022';
GO

-- Paso 4: Configurar el Modo de Alta Seguridad (opcional)

-- Configurar el modo de alta seguridad para el espejo
USE master;
GO
ALTER DATABASE DBVENTASDEMO SET SAFETY FULL;
GO

-- Paso 5: Verificar el estado del espejo
SELECT database_id, name, state_desc, recovery_model_desc
FROM sys.databases
WHERE name = 'DBVENTASDEMO';
GO
