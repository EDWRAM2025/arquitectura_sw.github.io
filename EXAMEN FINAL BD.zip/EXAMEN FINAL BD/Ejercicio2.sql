USE DBVENTASDEMO;
GO

CREATE VIEW VistaVentasDetalle
AS
SELECT 
    v.IdVenta,
    v.TipoDocumento,
    v.NumeroDocumento,
    v.NombreCliente,
    v.DocumentoCliente,
    p.Nombre AS NombreProducto,
    dv.Cantidad,
    dv.PrecioVenta,
    dv.SubTotal,
    v.FechaRegistro
FROM VENTA v
JOIN DETALLE_VENTA dv ON v.IdVenta = dv.IdVenta
JOIN PRODUCTO p ON dv.IdProducto = p.IdProducto;
GO

