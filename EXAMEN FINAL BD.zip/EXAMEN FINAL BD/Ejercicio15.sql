
BACKUP DATABASE DBVENTASDEMO
TO DISK = 'C:\Backups\DBVENTASDEMO.bak'
WITH FORMAT,
    MEDIANAME = 'DBVENTASDEMOBackup',
    NAME = 'Full Backups of DBVENTASDEMO';
GO

-- Comprobar si el archivo de respaldo existe
EXEC xp_fileexist 'C:\Backups\DBVENTASDEMO.bak';
