-- Crear la auditor�a para la base de datos
CREATE SERVER AUDIT MiAuditoria
    TO FILE (FILEPATH = 'C:\Auditor�aLogs\')
    WITH (QUEUE_DELAY = 1000, ON_FAILURE = CONTINUE);
GO

-- Activar la auditor�a
ALTER SERVER AUDIT MiAuditoria
    WITH (STATE = ON);
GO

-- Crear una especificaci�n de auditor�a para auditar acciones en la base de datos
CREATE SERVER AUDIT SPECIFICATION MiEspecificacionDeAuditoria
    FOR SERVER AUDIT MiAuditoria
    ADD (DATABASE_OBJECT_PERMISSION_CHANGE_GROUP),
    ADD (DATABASE_PRINCIPAL_CHANGE_GROUP),
    ADD (LOGIN_CHANGE_PASSWORD_GROUP),
    ADD (FAILED_LOGIN_GROUP)
    WITH (STATE = ON);
GO

-- Consultar los eventos de auditor�a desde el archivo
SELECT *
FROM fn_get_audit_file('C:\Auditor�aLogs\*.sqlaudit', NULL, NULL);
GO
