
-- Crear una vista que excluye la columna DOCUMENTO
CREATE VIEW USUARIO_VISTA_RESTRINGIDA AS
SELECT
    IdUsuario,
    NombreCompleto,
    Correo,
    Clave,
    IdRol,
    Estado,
    FechaRegistro
FROM USUARIO;
GO

-- Denegar acceso a la columna DOCUMENTO para el usuario LUIS_AQUINO
DENY SELECT ON USUARIO(DOCUMENTO) TO LUIS_AQUINO;
GO

-- Otorgar permisos de SELECT sobre la vista sin la columna DOCUMENTO
GRANT SELECT ON USUARIO_VISTA_RESTRINGIDA TO LUIS_AQUINO;
GO

