-- Crear una vista que excluye la columna DOCUMENTO para LUIS_AQUINO
CREATE VIEW USUARIO_VISTA_SIN_DOCUMENTO AS
SELECT
    IdUsuario,
    NombreCompleto,
    Correo,
    Clave,
    IdRol,
    Estado,
    FechaRegistro
FROM USUARIO;
GO

-- Denegar acceso al usuario LUIS_AQUINO a la tabla USUARIO
DENY SELECT ON USUARIO TO LUIS_AQUINO;
GO

-- Otorgar permisos al usuario LUIS_AQUINO sobre la vista sin la columna DOCUMENTO
GRANT SELECT ON USUARIO_VISTA_SIN_DOCUMENTO TO LUIS_AQUINO;
GO

-- Otorgar permisos a otros usuarios para acceder a la columna DOCUMENTO
GRANT SELECT ON USUARIO TO EDWIN_RAMIREZ_YARASCA; 
GO
