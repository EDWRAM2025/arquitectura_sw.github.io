USE DBVENTASDEMO;
GO

-- Crear un certificado para la encriptaci�n (opcional, pero recomendado para almacenamiento seguro)
CREATE CERTIFICATE MyCertificate
    WITH SUBJECT = 'Clave de Encriptaci�n para USUARIO';

-- Crear una clave sim�trica para la encriptaci�n
CREATE SYMMETRIC KEY MySymmetricKey
    WITH ALGORITHM = AES_256
    ENCRYPTION BY CERTIFICATE MyCertificate;
GO

-- Abrir la clave sim�trica para encriptar los datos
OPEN SYMMETRIC KEY MySymmetricKey
    DECRYPTION BY CERTIFICATE MyCertificate;

-- Encriptar los datos de la tabla USUARIO
UPDATE USUARIO
SET 
    Correo = ENCRYPTBYKEY(KEY_GUID('MySymmetricKey'), Correo),
    Clave = ENCRYPTBYKEY(KEY_GUID('MySymmetricKey'), Clave)
WHERE Estado = 1;

-- Cerrar la clave sim�trica despu�s de encriptar
CLOSE SYMMETRIC KEY MySymmetricKey;
GO
