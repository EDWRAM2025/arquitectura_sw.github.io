-- Crear una clave maestra de base de datos (si a�n no existe)
CREATE DATABASE ENCRYPTION KEY;
GO

-- Crear un certificado para el cifrado de la base de datos
CREATE CERTIFICATE TDE_Certificate
WITH SUBJECT = 'Certificado para TDE';
GO

-- Habilitar TDE en la base de datos DBVENTASDEMO
ALTER DATABASE DBVENTASDEMO
SET ENCRYPTION ON;
GO

-- Verificar el estado de TDE en la base de datos
SELECT name, is_encrypted
FROM sys.databases
WHERE name = 'DBVENTASDEMO';
GO

-- Realizar una copia de seguridad del certificado
BACKUP CERTIFICATE TDE_Certificate
TO FILE = 'C:\Backup\TDE_Certificate.cer'
WITH PRIVATE KEY (
    FILE = 'C:\Backup\TDE_Certificate_PrivateKey.pvk',
    ENCRYPTION BY PASSWORD = 'MiContrase�aSegura'
);
GO

