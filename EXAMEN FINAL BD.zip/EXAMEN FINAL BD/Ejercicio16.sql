-- Primero, asegur�monos de que la base de datos no est� en uso
USE master;
GO

-- Desconectar la base de datos si ya existe (opcional)
IF EXISTS (SELECT name FROM sys.databases WHERE name = 'DBVENTASDEMO')
BEGIN
    ALTER DATABASE DBVENTASDEMO SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
END
GO

-- Restaurar la base de datos desde el archivo de respaldo
RESTORE DATABASE DBVENTASDEMO
FROM DISK = 'C:\Backupss\DBVENTASDEMO.bak'
WITH REPLACE, 
    MOVE 'DBVENTASDEMO' TO 'C:\SQLData\DBVENTASDEMO.mdf', -- Aseg�rate de poner la ruta correcta para el archivo de datos
    MOVE 'DBVENTASDEMO_log' TO 'C:\SQLData\DBVENTASDEMO_log.ldf'; -- Aseg�rate de poner la ruta correcta para el archivo de registro
GO

-- Volver a poner la base de datos en modo multiusuario
ALTER DATABASE DBVENTASDEMO SET MULTI_USER;
GO
