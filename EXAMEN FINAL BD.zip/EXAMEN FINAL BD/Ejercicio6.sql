

BACKUP DATABASE DBVENTASDEMO
TO DISK = 'C:\backups\DBVENTASDEMO.bak';
GO

RESTORE DATABASE DBVENTASDEMO_COPIA
FROM DISK = 'C:\backups\DBVENTASDEMO.bak'
WITH 
    MOVE 'DBVENTASDEMO' TO 'C:\SQLData\DBVENTASDEMO_COPIA.mdf', 
    MOVE 'DBVENTASDEMO_log' TO 'C:\SQLData\DBVENTASDEMO_COPIA_log.ldf';
GO


USE DBVENTASDEMO_COPIA;
GO

-- Crear usuarios en la base de datos copiada y asignarles permisos
-- Usuario LUIS AQUINO
CREATE USER LUIS_AQUINO FOR LOGIN LUIS_AQUINO;
EXEC sp_addrolemember 'db_datareader', 'LUIS_AQUINO';
EXEC sp_addrolemember 'db_datawriter', 'LUIS_AQUINO'; -- Si quieres permisos de escritura
GO

-- Usuario DAYANA RIOS
CREATE USER DAYANA_RIOS FOR LOGIN DAYANA_RIOS;
EXEC sp_addrolemember 'db_datareader', 'DAYANA_RIOS';
EXEC sp_addrolemember 'db_datawriter', 'DAYANA_RIOS'; -- Si quieres permisos de escritura
GO

-- Usuario EDWIN RAMIREZ YARASCA
CREATE USER EDWIN_RAMIREZ_YARASCA FOR LOGIN EDWIN_RAMIREZ_YARASCA;
EXEC sp_addrolemember 'db_datareader', 'EDWIN_RAMIREZ_YARASCA';
EXEC sp_addrolemember 'db_datawriter', 'EDWIN_RAMIREZ_YARASCA'; -- Si quieres permisos de escritura
GO
