USE DBVENTASDEMO;
GO

CREATE TRIGGER VerificarEstadoProducto
ON PRODUCTO
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    -- Verificar que el campo Estado solo sea 1 o 0
    IF EXISTS (
        SELECT 1
        FROM inserted
        WHERE Estado NOT IN (0, 1)
    )
    BEGIN
        -- Revertir la operaci�n y lanzar un error
        ROLLBACK TRANSACTION;
        THROW 50000, 'El campo Estado debe ser 0 o 1.', 1;
    END
END;
GO