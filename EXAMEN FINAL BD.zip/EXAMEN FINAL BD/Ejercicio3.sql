USE DBVENTASDEMO;
GO

CREATE PROCEDURE ModificarProductoSecuencial
    @IdProducto INT,
    @Nombre NVARCHAR(50),
    @Descripcion NVARCHAR(50),
    @Stock INT,
    @PrecioCompra DECIMAL(10,2),
    @PrecioVenta DECIMAL(10,2)
AS
BEGIN
    SET NOCOUNT ON;

    -- Validar si el producto existe
    IF EXISTS (SELECT 1 FROM PRODUCTO WHERE IdProducto = @IdProducto)
    BEGIN
        -- Actualizar el producto en forma secuencial
        BEGIN TRANSACTION;

        BEGIN TRY
            -- Actualizar nombre y descripci�n
            UPDATE PRODUCTO
            SET Nombre = @Nombre,
                Descripcion = @Descripcion
            WHERE IdProducto = @IdProducto;

            -- Actualizar stock
            UPDATE PRODUCTO
            SET Stock = @Stock
            WHERE IdProducto = @IdProducto;

            -- Actualizar precios
            UPDATE PRODUCTO
            SET PrecioCompra = @PrecioCompra,
                PrecioVenta = @PrecioVenta
            WHERE IdProducto = @IdProducto;

            -- Confirmar la transacci�n
            COMMIT TRANSACTION;
        END TRY
        BEGIN CATCH
            -- Revertir la transacci�n en caso de error
            ROLLBACK TRANSACTION;
            THROW;
        END CATCH
    END
    ELSE
    BEGIN
        PRINT 'El producto no existe.';
    END
END
GO
;