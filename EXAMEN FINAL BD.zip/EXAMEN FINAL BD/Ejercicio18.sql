-- Paso 1: Activar la replicaci�n en el servidor publicador
USE master;
GO
-- Habilitar la base de datos como publicador
EXEC sp_replicationdboption 
    @dbname = 'DBVENTASDEMO', 
    @optname = 'publish', 
    @value = 'true';
GO

-- Paso 2: Configurar la base de datos de distribuci�n
EXEC sp_adddistributor 
    @distributor = 'ServidorPublicador',  -- Nombre del servidor publicador
    @password = 'Contrase�aDistribuidor'; -- Contrase�a del distribuidor
GO

-- Paso 3: Crear la base de datos de distribuci�n
EXEC sp_adddistributiondb 
    @database = 'distribution', 
    @security_mode = 1;  -- Modo de seguridad para la base de datos de distribuci�n
GO

-- Paso 4: Crear el publicador
EXEC sp_addpublisher 
    @publisher = 'ServidorPublicador',  -- Nombre del servidor publicador
    @distribution_db = 'distribution'; -- Base de datos de distribuci�n
GO

-- Paso 5: Configurar el servidor suscriptor
USE master;
GO
EXEC sp_addsubscriber 
    @subscriber = 'ServidorSuscriptor';  -- Nombre del servidor suscriptor
GO

-- Paso 6: Crear la publicaci�n en el servidor publicador
USE DBVENTASDEMO;
GO
EXEC sp_addpublication 
    @publication = 'DBVENTASDEMO_Publication',  -- Nombre de la publicaci�n
    @publication_type = 'transactional',  -- Tipo de replicaci�n: transaccional
    @description = 'Replicaci�n transaccional de la base de datos DBVENTASDEMO',
    @sync_method = 'native', 
    @article = 'all';  -- Publicar todas las tablas
GO

-- Paso 7: Crear art�culos de la publicaci�n (tablas a replicar)
EXEC sp_addarticle 
    @publication = 'DBVENTASDEMO_Publication',
    @article = 'PRODUCTO', 
    @source_object = 'PRODUCTO', 
    @type = 'logbased', 
    @description = 'Tabla PRODUCTO';
GO

EXEC sp_addarticle 
    @publication = 'DBVENTASDEMO_Publication',
    @article = 'CLIENTE', 
    @source_object = 'CLIENTE', 
    @type = 'logbased', 
    @description = 'Tabla CLIENTE';
GO

-- Paso 8: Crear la suscripci�n en el servidor suscriptor
EXEC sp_addsubscription 
    @publication = 'DBVENTASDEMO_Publication', 
    @subscriber = 'ServidorSuscriptor',
    @subscription_type = 'push',  -- Tipo de suscripci�n: push (el publicador env�a los datos)
    @sync_type = 'automatic';  -- Sincronizaci�n autom�tica
GO

-- Paso 9: Configurar el Agente de Replicaci�n para distribuci�n
USE distribution;
GO
EXEC sp_adddistpublisher 
    @publisher = 'ServidorPublicador', 
    @distribution_db = 'distribution';
GO

-- Paso 10: Configurar el agente de replicaci�n
EXEC sp_adddistributiondb 
    @database = 'distribution';
GO

-- Paso 11: Iniciar la replicaci�n
EXEC sp_startpublication_snapshot 
    @publication = 'DBVENTASDEMO_Publication';
GO
