use master
go
Create database GestionEmpleado
on primary
	(name = GestionEmpleado_Data,
	filename= 'F:\BaseDatos2024\GestionEmpleado_Data.mdf',
	size = 5,
	maxsize = 20,
	filegrowth = 5)
log on
	(name = GestionEmpleado_Log,
	filename = 'F:\BaseDatos2024\GestionEmpleado_Log.ldf',
	size = 1,
	maxsize = 4,
	filegrowth = 1)
go