use GestionEmpleado
go
--11--
SELECT nombre, 
       (presupuesto - gastos) AS presupuesto_actual 
FROM departamento;
go
--12--
SELECT nombre, 
       (presupuesto - gastos) AS presupuesto_actual 
	FROM departamento
	ORDER BY presupuesto_actual ASC;
go
--13--
SELECT nombre 
	FROM departamento
	ORDER BY nombre ASC;
go
--14--
SELECT nombre 
	FROM departamento
	ORDER BY nombre DESC;
go
--15--
SELECT apePaterno, apeMaterno, nombre 
	FROM empleado
	ORDER BY apePaterno ASC, apeMaterno ASC, nombre ASC;
go
--16--
SELECT nombre, presupuesto 
	FROM departamento
	ORDER BY presupuesto DESC
	OFFSET 0 ROWS
	FETCH FIRST 3 ROWS ONLY;
go
--17--
SELECT nombre, presupuesto 
	FROM departamento
	ORDER BY presupuesto ASC
	OFFSET 0 ROWS
	FETCH FIRST 3 ROWS ONLY;
go
--18--
SELECT nombre, gastos 
	FROM departamento
	ORDER BY gastos DESC
	OFFSET 0 ROWS
	FETCH FIRST 2 ROWS ONLY;
go
--19--
SELECT nombre, gastos 
	FROM departamento
	ORDER BY gastos ASC
	OFFSET 0 ROWS
	FETCH FIRST 2 ROWS ONLY;
go
--20--
SELECT * 
	FROM empleado
	ORDER BY codigo
	OFFSET 2 ROWS
	FETCH NEXT 5 ROWS ONLY;
go