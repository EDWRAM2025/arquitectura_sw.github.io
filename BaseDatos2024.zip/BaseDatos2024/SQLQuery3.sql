USE GestionEmpleado;
GO

-- Insertar valores en la tabla departamento
INSERT INTO departamento (nombre, presupuesto, gastos) VALUES ('Desarrollo', 120000, 6000);
INSERT INTO departamento (nombre, presupuesto, gastos) VALUES ('Sistemas', 150000, 21000);
INSERT INTO departamento (nombre, presupuesto, gastos) VALUES ('Recursos Humanos', 280000, 25000);
INSERT INTO departamento (nombre, presupuesto, gastos) VALUES ('Contabilidad', 110000, 3000);
INSERT INTO departamento (nombre, presupuesto, gastos) VALUES ('I+D', 375000, 380000);
INSERT INTO departamento (nombre, presupuesto, gastos) VALUES ('Proyectos', 0, 0);
INSERT INTO departamento (nombre, presupuesto, gastos) VALUES ('Publicidad', 0, 1000);

-- Insertar valores en la tabla empleado
INSERT INTO empleado (dni, nombre, apePaterno, apeMaterno, codigo_departamento) 
VALUES ('32481596', 'Aar�n', 'Rivero', 'G�mez', 1);
INSERT INTO empleado (dni, nombre, apePaterno, apeMaterno, codigo_departamento) 
VALUES ('35575632', 'Adela', 'Salas', 'Diaz', 2);
INSERT INTO empleado (dni, nombre, apePaterno, apeMaterno, codigo_departamento) 
VALUES ('46970642', 'Adolfo', 'Rubio', 'Flores', 3);
INSERT INTO empleado (dni, nombre, apePaterno, apeMaterno, codigo_departamento) 
VALUES ('77705545', 'Adrian', 'Su�rez', NULL, 4);
INSERT INTO empleado (dni, nombre, apePaterno, apeMaterno, codigo_departamento) 
VALUES ('17087203', 'Marcos', 'Loyola', 'M�ndez', 5);
INSERT INTO empleado (dni, nombre, apePaterno, apeMaterno, codigo_departamento) 
VALUES ('38382980', 'Maria', 'Santana', 'Moreno', 1);
INSERT INTO empleado (dni, nombre, apePaterno, apeMaterno, codigo_departamento) 
VALUES ('80576669', 'Pilar', 'Ruiz', NULL, 2);
INSERT INTO empleado (dni, nombre, apePaterno, apeMaterno, codigo_departamento) 
VALUES ('71651431', 'Pepe', 'Ruiz', 'Santana', 3);
INSERT INTO empleado (dni, nombre, apePaterno, apeMaterno, codigo_departamento) 
VALUES ('56399183', 'Juan', 'Gomez', 'L�pez', 2);
INSERT INTO empleado (dni, nombre, apePaterno, apeMaterno, codigo_departamento) 
VALUES ('46384486', 'Diego', 'Flores', 'Salas', 5);
INSERT INTO empleado (dni, nombre, apePaterno, apeMaterno, codigo_departamento) 
VALUES ('67389283', 'Marta', 'Herrera', 'Gil', 1);
INSERT INTO empleado (dni, nombre, apePaterno, apeMaterno, codigo_departamento) 
VALUES ('41234836', 'Irene', 'Salas', 'Flores', NULL);
INSERT INTO empleado (dni, nombre, apePaterno, apeMaterno, codigo_departamento) 
VALUES ('82635162', 'JuanAntonio', 'S�ez', 'Guerrero', NULL);
