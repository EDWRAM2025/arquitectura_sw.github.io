--Consulta resumen--
--1--
SELECT SUM(presupuesto) AS total_presupuesto
FROM departamento;

--2--
SELECT AVG(presupuesto) AS promedio_presupuesto
FROM departamento;

--3--
SELECT MIN(presupuesto) AS presupuesto_minimo
FROM departamento;

--4--
SELECT nombre, presupuesto
FROM departamento
WHERE presupuesto = (SELECT MIN(presupuesto) FROM departamento);

--5--
SELECT MAX(presupuesto) AS presupuesto_maximo
FROM departamento;

--6--
SELECT nombre, presupuesto
FROM departamento
WHERE presupuesto = (SELECT MAX(presupuesto) FROM departamento);

--7--
SELECT COUNT(*) AS total_empleados
FROM empleado;

--8--
SELECT COUNT(*) AS empleados_con_apMaterno
FROM empleado
WHERE apeMaterno IS NOT NULL;

--9--
SELECT d.nombre, COUNT(e.codigo) AS num_empleados
FROM departamento d
LEFT JOIN empleado e ON d.codigo = e.codigo_departamento
GROUP BY d.nombre;

--10--
SELECT d.nombre, COUNT(e.codigo) AS num_empleados
FROM departamento d
LEFT JOIN empleado e ON d.codigo = e.codigo_departamento
GROUP BY d.nombre
HAVING COUNT(e.codigo) > 2;

--11--
SELECT d.nombre, COUNT(e.codigo) AS num_empleados
FROM departamento d
LEFT JOIN empleado e ON d.codigo = e.codigo_departamento
GROUP BY d.nombre;

--12--
SELECT d.nombre AS departamento, COUNT(e.codigo) AS num_empleados
FROM departamento d
JOIN empleado e ON d.codigo = e.codigo_departamento
WHERE d.presupuesto > 200000
GROUP BY d.nombre;
GO