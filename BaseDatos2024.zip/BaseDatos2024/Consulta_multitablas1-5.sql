--Consulta Multitablas--
--1--
SELECT e.*, d.*
FROM empleado e
LEFT JOIN departamento d ON e.codigo_departamento = d.codigo;

--2--
SELECT e.*
FROM empleado e
LEFT JOIN departamento d ON e.codigo_departamento = d.codigo
WHERE e.codigo_departamento IS NULL;

--3--
SELECT d.*
FROM departamento d
LEFT JOIN empleado e ON d.codigo = e.codigo_departamento
WHERE e.codigo_departamento IS NULL;

--4--
SELECT e.*, d.*
FROM empleado e
FULL OUTER JOIN departamento d ON e.codigo_departamento = d.codigo
ORDER BY d.nombre ASC;

--5--
SELECT e.*, d.*
FROM empleado e
FULL OUTER JOIN departamento d ON e.codigo_departamento = d.codigo
WHERE e.codigo_departamento IS NULL OR d.codigo NOT IN (SELECT codigo_departamento FROM empleado)
ORDER BY d.nombre ASC;



