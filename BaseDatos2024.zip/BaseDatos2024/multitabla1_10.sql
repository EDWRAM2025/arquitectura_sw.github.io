--MULTITABLA--
--1--
SELECT 
    CONCAT(empleado.nombre, ' ', empleado.apePaterno, ' ', empleado.apeMaterno) AS nombre_completo, 
    departamento.nombre
FROM 
    empleado
JOIN 
    departamento ON empleado.codigo_departamento = departamento.codigo;
go
--2--
SELECT CONCAT(empleado.nombre, ' ', empleado.apePaterno, ' ', empleado.apeMaterno) AS nombre_completo, 
    departamento.nombre
FROM empleado
INNER JOIN departamento ON empleado.codigo_departamento = departamento.codigo
ORDER BY departamento.nombre, empleado.apePaterno, empleado.nombre;
--3--
SELECT DISTINCT d.codigo, d.nombre
FROM departamento d
JOIN empleado e ON d.codigo = e.codigo_departamento;
--4--
SELECT d.codigo, d.nombre, (d.presupuesto - d.gastos) AS presupuesto_actual
FROM departamento d
JOIN empleado e ON d.codigo = e.codigo_departamento;
--5--
SELECT d.nombre
FROM empleado e
JOIN departamento d ON e.codigo_departamento = d.codigo
WHERE e.dni = '38382980';
--6--
SELECT d.nombre
FROM empleado e
JOIN departamento d ON e.codigo_departamento = d.codigo
WHERE e.nombre = 'Pepe' AND e.apePaterno = 'Ruiz' AND e.apeMaterno = 'Santana';  
GO
--7--
SELECT e.*
FROM empleado e
JOIN departamento d ON e.codigo_departamento = d.codigo
WHERE d.nombre = 'I+D'
ORDER BY e.apePaterno, e.nombre;
--8--
SELECT e.*
FROM empleado e
JOIN departamento d ON e.codigo_departamento = d.codigo
WHERE d.nombre IN ('Sistemas', 'Contabilidad', 'I+D')
ORDER BY e.apePaterno, e.nombre;
--9--
SELECT e.nombre, e.apePaterno, e.apeMaterno
FROM empleado e
JOIN departamento d ON e.codigo_departamento = d.codigo
WHERE d.presupuesto < 100000 OR d.presupuesto > 200000;
GO
--10--
SELECT DISTINCT d.nombre
FROM empleado e
JOIN departamento d ON e.codigo_departamento = d.codigo
WHERE e.apeMaterno IS NULL;
