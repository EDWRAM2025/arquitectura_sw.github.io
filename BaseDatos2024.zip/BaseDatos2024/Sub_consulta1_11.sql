--Subconsulta--
-- Con operadores b�sicos de cmparaci�n--
--1--
SELECT nombre, apePaterno, apeMaterno
FROM empleado
WHERE codigo_departamento = (SELECT codigo FROM departamento WHERE nombre = 'Sistemas');
GO

--2--
SELECT nombre, presupuesto
FROM departamento
WHERE presupuesto = (SELECT MAX(presupuesto) FROM departamento);
GO

--3--
SELECT nombre, presupuesto
FROM departamento
WHERE presupuesto = (SELECT MIN(presupuesto) FROM departamento);
GO

--Sub consultas con ALL y ANY--
--4--
SELECT nombre, presupuesto
FROM departamento
WHERE presupuesto >= ALL (SELECT presupuesto FROM departamento);
GO

--5--
SELECT nombre, presupuesto
FROM departamento
WHERE presupuesto <= ALL (SELECT presupuesto FROM departamento);
GO

--6--
SELECT nombre
FROM departamento
WHERE codigo = ANY (SELECT codigo_departamento FROM empleado);
GO

--7--
SELECT nombre
FROM departamento d
WHERE d.codigo != ANY (SELECT codigo_departamento FROM empleado);
GO

--Sub consultas con IN y NOT IN--
--8--
SELECT nombre
FROM departamento
WHERE codigo IN (SELECT codigo_departamento FROM empleado);
GO

--9--
SELECT nombre
FROM departamento
WHERE codigo IN (SELECT codigo_departamento FROM empleado);
GO

--Sub consultas con EXIST y NOT EXISTS--
--10--
SELECT nombre
FROM departamento d
WHERE EXISTS (SELECT 1 FROM empleado e WHERE e.codigo_departamento = d.codigo);
GO

--11--

SELECT nombre
FROM departamento d
WHERE NOT EXISTS (SELECT 1 FROM empleado e WHERE e.codigo_departamento = d.codigo);
GO
