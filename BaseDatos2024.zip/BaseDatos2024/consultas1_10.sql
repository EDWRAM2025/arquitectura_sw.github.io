use GestionEmpleado
go
--1--
select apePaterno
	from empleado;
go
--2--
select distinct apePaterno
	from empleado
go
--3--
SELECT * 
	FROM empleado;
go
--4--
SELECT nombre, apePaterno, apeMaterno 
	FROM empleado;
go
--5--
SELECT codigo_departamento 
	FROM empleado;
go
--6--
SELECT DISTINCT codigo_departamento 
	FROM empleado;
go
--7--
SELECT CONCAT(nombre, ' ', apePaterno, ' ', apeMaterno) AS nombre_completo 
	FROM empleado;
go
--8--
SELECT UPPER(CONCAT(nombre, ' ', apePaterno, ' ', apeMaterno)) AS nombre_completo 
	FROM empleado;
go
--9--
SELECT LOWER(CONCAT(nombre, ' ', apePaterno, ' ', apeMaterno)) AS nombre_completo 
	FROM empleado;
go
--10--
SELECT codigo, 
       LEFT(dni, LEN(dni) - 1) AS nif_digitos, 
       RIGHT(dni, 1) AS nif_letra 
	FROM empleado;
go













