use GestionEmpleado
go
--21--
SELECT nombre, presupuesto 
	FROM departamento
	WHERE presupuesto >= 150000;
go
--22--
SELECT nombre, gastos 
	FROM departamento
	WHERE gastos < 5000;
go
--23--
SELECT nombre, presupuesto 
	FROM departamento
	WHERE presupuesto >= 100000 AND presupuesto <= 200000;
go
--24--
SELECT nombre 
	FROM departamento
	WHERE presupuesto < 100000 OR presupuesto > 200000;
go
--25--
SELECT nombre, presupuesto 
	FROM departamento
	WHERE presupuesto BETWEEN 100000 AND 200000;
go
--26--
SELECT nombre 
	FROM departamento
	WHERE presupuesto NOT BETWEEN 100000 AND 200000;
go
--27--
SELECT nombre, gastos, presupuesto 
	FROM departamento
	WHERE gastos > presupuesto;
go
--28--
SELECT nombre, gastos, presupuesto 
	FROM departamento
	WHERE gastos < presupuesto;
go
--29--
SELECT nombre, gastos, presupuesto 
	FROM departamento
	WHERE gastos = presupuesto;
go
--30--
SELECT * 
	FROM empleado
	WHERE apeMaterno IS NULL;
go




