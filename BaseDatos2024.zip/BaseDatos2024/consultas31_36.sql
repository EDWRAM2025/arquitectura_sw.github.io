use GestionEmpleado
go
--31--
SELECT * 
	FROM empleado
	WHERE apeMaterno IS NOT NULL;
go
--32--
SELECT * 
	FROM empleado
	WHERE apeMaterno = 'L�pez';
go
--33--
SELECT * 
	FROM empleado
	WHERE apeMaterno = 'D�az' OR apeMaterno = 'Moreno';
go
--34--
SELECT * 
	FROM empleado
	WHERE apeMaterno IN ('D�az', 'Moreno');
go
--35--
SELECT nombre, apePaterno, apeMaterno, dni 
	FROM empleado
	WHERE codigo_departamento = 3;
go
--36--
SELECT nombre, apePaterno, apeMaterno, dni 
	FROM empleado
	WHERE codigo_departamento IN (2, 4, 5);
go