use GestionEmpleado
go
CREATE TABLE departamento ( 
	codigo INT IDENTITY(1,1) PRIMARY KEY,
	nombre VARCHAR(100) NOT NULL, 
	presupuesto numeric (10, 2) NOT NULL, 
	gastos numeric(10, 2) NOT NULL,
)
CREATE TABLE empleado ( 
	codigo INT IDENTITY(1,1) PRIMARY KEY, 
	dni VARCHAR (8) NOT NULL UNIQUE, 
	nombre VARCHAR(100) NOT NULL, 
	apePaterno VARCHAR (100) NOT NULL, 
	apeMaterno VARCHAR(100), 
	codigo_departamento INT, 
	FOREIGN KEY (codigo_departamento) REFERENCES departamento (codigo)
)
go
